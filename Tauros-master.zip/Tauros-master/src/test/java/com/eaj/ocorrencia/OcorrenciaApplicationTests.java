package com.eaj.ocorrencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcorrenciaApplicationTests {

    @Test
    void contextLoads() {
    }

}
