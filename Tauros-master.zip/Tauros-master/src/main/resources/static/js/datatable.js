$(document).ready(function () {
    $('#table_id').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
        },
        "searching": true,
        paging: true,
    });
});
$(document).ready(function () {
    $('#table_id2').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
        },
        "searching": true,
        paging: true,
    });
});
$(document).ready(function () {
    $('#table_id3').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
        },
        "searching": true,
        paging: true,
    });
});
$(document).ready(function () {
    $('#table_id4').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
        },
        "searching": true,
        paging: true,
    });
});