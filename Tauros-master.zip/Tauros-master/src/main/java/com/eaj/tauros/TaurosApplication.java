package com.eaj.tauros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaurosApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaurosApplication.class, args);
    }

}
